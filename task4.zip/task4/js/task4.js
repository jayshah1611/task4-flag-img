function setTextIndia() {
    document.getElementById("textName").value = "INDIA";
  }

  function setTextAmeriaca() {
    document.getElementById("textName").value = "UNITED KINGDOM ";
  }

  function setTextJapan() {
    document.getElementById("textName").value = "JAPAN";
  }
  
  function clearText() {
    document.getElementById("textName").value = "";
    
  }